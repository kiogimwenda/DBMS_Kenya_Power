create definer = root@localhost view v_fault_metrics as
select cast(`kenya_power_db`.`faults`.`reported_date` as date)         AS `report_date`,
       count(0)                                                        AS `total_faults`,
       sum((case
                when ((`kenya_power_db`.`faults`.`status` = 'resolved') or
                      (`kenya_power_db`.`faults`.`status` = 'closed')) then 1
                else 0 end))                                           AS `resolved_faults`,
       avg(timestampdiff(HOUR, `kenya_power_db`.`faults`.`reported_date`,
                         `kenya_power_db`.`faults`.`resolution_date`)) AS `avg_resolution_hours`,
       sum(`kenya_power_db`.`faults`.`affected_customers`)             AS `total_affected_customers`
from `kenya_power_db`.`faults`
group by cast(`kenya_power_db`.`faults`.`reported_date` as date);

