create definer = root@localhost view v_maintenance_calendar as
select `m`.`maintenance_id`       AS `maintenance_id`,
       `m`.`title`                AS `title`,
       `m`.`maintenance_type`     AS `maintenance_type`,
       `m`.`equipment_type`       AS `equipment_type`,
       `m`.`scheduled_date`       AS `scheduled_date`,
       `m`.`scheduled_time`       AS `scheduled_time`,
       `m`.`status`               AS `status`,
       `m`.`priority`             AS `priority`,
       `m`.`location_description` AS `location_description`,
       `u`.`full_name`            AS `assigned_technician`
from (`kenya_power_db`.`maintenance_schedules` `m` left join `kenya_power_db`.`users` `u`
      on ((`m`.`assigned_to` = `u`.`user_id`)))
where (`m`.`status` in ('scheduled', 'in_progress'));

