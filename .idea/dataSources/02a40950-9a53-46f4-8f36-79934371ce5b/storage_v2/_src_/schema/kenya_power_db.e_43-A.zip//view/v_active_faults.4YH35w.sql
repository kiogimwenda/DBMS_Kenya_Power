create definer = root@localhost view v_active_faults as
select `f`.`fault_id`                                 AS `fault_id`,
       `f`.`fault_type`                               AS `fault_type`,
       `f`.`severity`                                 AS `severity`,
       `f`.`status`                                   AS `status`,
       `f`.`reported_date`                            AS `reported_date`,
       `f`.`affected_customers`                       AS `affected_customers`,
       `c`.`account_number`                           AS `account_number`,
       concat(`c`.`first_name`, ' ', `c`.`last_name`) AS `customer_name`,
       `conn`.`meter_number`                          AS `meter_number`,
       `u`.`full_name`                                AS `assigned_technician`
from (((`kenya_power_db`.`faults` `f` left join `kenya_power_db`.`customers` `c`
        on ((`f`.`reported_by_customer` = `c`.`customer_id`))) left join `kenya_power_db`.`connections` `conn`
       on ((`f`.`connection_id` = `conn`.`connection_id`))) left join `kenya_power_db`.`users` `u`
      on ((`f`.`assigned_to` = `u`.`user_id`)))
where (`f`.`status` not in ('resolved', 'closed'));

